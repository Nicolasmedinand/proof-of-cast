export default function Leaderboard() {
  return (
    <main className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-semibold">Leaderboard</h1>
      <p className="mt-2">Top users by Proof of Cast score.</p>
      {/* Table placeholder */}
      <div className="mt-6 border rounded p-4">Coming soon…</div>
    </main>
  );
}
