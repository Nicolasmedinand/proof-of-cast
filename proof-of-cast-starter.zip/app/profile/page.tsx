export default function Profile() {
  return (
    <main className="p-8 max-w-3xl mx-auto">
      <h1 className="text-2xl font-semibold">My Profile</h1>
      <p className="mt-2">Sync your data and mint your badge once you reach a threshold.</p>
      {/* Implement real data fetching and actions */}
      <div className="mt-6 flex gap-4">
        <button className="border px-4 py-2 rounded">Sync</button>
        <button className="border px-4 py-2 rounded">Mint badge</button>
      </div>
    </main>
  );
}
