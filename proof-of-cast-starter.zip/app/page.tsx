export default function Home() {
  return (
    <main className="p-8 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold">Proof of Cast</h1>
      <p className="mt-2">On-chain reputation for Farcaster users on Base.</p>
      <ul className="mt-6 list-disc pl-6">
        <li>Sign in with Farcaster</li>
        <li>Sync interactions and compute your score</li>
        <li>Mint your badge on Base</li>
      </ul>
    </main>
  );
}
