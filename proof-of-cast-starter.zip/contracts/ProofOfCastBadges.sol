// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC1155/ERC1155.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract ProofOfCastBadges is ERC1155, Ownable {
    mapping(address => bool) public isMinter;

    constructor(string memory baseUri) ERC1155(baseUri) {}

    function setMinter(address m, bool v) external onlyOwner { isMinter[m] = v; }

    function mintTo(address to, uint256 level) external {
        require(isMinter[msg.sender], "not minter");
        _mint(to, level, 1, "");
    }

    // Soulbound (non-transferable)
    function setApprovalForAll(address, bool) public pure override { revert("SBT"); }
    function safeTransferFrom(address, address, uint256, uint256, bytes memory) public pure override { revert("SBT"); }
    function safeBatchTransferFrom(address, address, uint256[] memory, uint256[] memory, bytes memory) public pure override { revert("SBT"); }
}
