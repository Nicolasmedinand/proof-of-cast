# Proof of Cast – Base + Farcaster (Starter)

This is a **deployment-ready skeleton** for the Proof of Cast mini app.

## What’s included
- Next.js (app dir) skeleton with pages: Home, Profile, Leaderboard
- API routes: auth, score, leaderboard, sync, mint, hourly cron
- Prisma schema with User, Interaction, BadgeMint, ScoreHistory
- ERC-1155 Soulbound contract (non-transferable) for badges
- Deployment helpers: `vercel.json`, `.env.example`, deploy script

> This is a starter codebase to paste keys and extend inside Ohara or your editor.

## Quickstart

1. **Copy envs**
```bash
cp .env.example .env
```

2. **Install & Prisma**
```bash
pnpm i
pnpm dlx prisma generate
pnpm dlx prisma migrate dev
```

3. **Deploy contract (Base Sepolia)**
```bash
pnpm contract:deploy:sepolia
# copy CONTRACT_ADDRESS into .env
```

4. **Run**
```bash
pnpm dev
```

5. **Deploy to Vercel**
- Set env vars in Project Settings
- Post-deploy command: `pnpm run db:migrate`

