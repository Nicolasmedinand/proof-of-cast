import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { fid } = req.query;
  // TODO: read from Postgres via Prisma
  return res.status(200).json({ fid, score: 0, level: 0, lastSyncAt: null });
}
