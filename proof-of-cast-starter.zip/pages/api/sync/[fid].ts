import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { fid } = req.query;
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  // TODO: fetch interactions from Neynar and recompute score
  return res.status(200).json({ fid, synced: true });
}
