import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  // TODO: integrate Neynar Sign in with Farcaster
  return res.status(200).json({ ok: true, message: 'Login placeholder' });
}
