import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(_req: NextApiRequest, res: NextApiResponse) {
  // TODO: recompute scores hourly (decay half-life 7 days)
  return res.status(200).json({ ok: true, ranAt: new Date().toISOString() });
}
